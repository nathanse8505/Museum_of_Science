"""
File: main.py
Purpose: Main function for the car plotter exhibit
"""

import math
import pygame
from pygame.locals import *
from consts import *
from asset_loader import *
from graph import Graph
from user import User
from logs import *
from arduino import *
import time

def main():
    logger = get_logger()
    logger.info("Starting Car Plotter Exhibit")

    pygame.init()
    pygame.display.set_caption("Car Plot")
    clock = pygame.time.Clock()
    pygame.mouse.set_visible(False)


    if FULLSCREEN:
        screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
        screen_width, screen_height = pygame.display.Info().current_w, pygame.display.Info().current_h
        view_port = (screen_width, screen_height)

    else:
        screen = pygame.display.set_mode(VIEWPORT)
        view_port = VIEWPORT

    # arduino setup
    arduino_port = find_arduino_port(logger=logger)  # find the serial port
    ser = open_serial_connection(arduino_port, logger=logger)  # Open the serial port
    last_time_tried_to_connect = time.time()  # for not trying to connect too often


    asset_loader = AssetLoader(ASSETS_DIR, PICTURES_TO_LOAD, view_port)
    user = User(
        screen,
        (0, 1000), (-500, 500),
        (
            asset_loader.pictures["grid"][1][0],
            asset_loader.pictures["grid"][1][1],
            asset_loader.pictures["grid"][0].get_width(),
            asset_loader.pictures["grid"][0].get_height()
        ),
    )

    def sinusodial(x):
        if x <= 157:
            return 3.185 * x - 500
        return - 300 * math.sin(0.02 * x)
    
    def cool_function(x):
        """
        x: in range [0, 1000]
        returns y in range roughly [-500, 500]
        """
        y = 250 * math.sin(x * 0.02)  # Base wave
        y += 120 * math.sin(x * 0.1 + math.sin(x * 0.03))  # Nested sine wave
        y += 90 * math.cos(x * 0.005 + math.sin(x * 0.01))  # Curvy wiggles
        y += 70 * math.tan(math.sin(x * 0.004)) / 2  # Occasional spikes
        y += 80 * math.exp(-((x - 700) ** 2) / 5000)  # Sharp bump
        return y
    
   
    # Create a graph object
    graphs = [
        Graph(
            screen,
            lambda x: 500 - x,
            (0, 1000), (-500, 500),
            (
                asset_loader.pictures["grid"][1][0],
                asset_loader.pictures["grid"][1][1],
                asset_loader.pictures["grid"][0].get_width(),
                asset_loader.pictures["grid"][0].get_height()
            ),
            title="Linear Function"
        ),
        Graph(
            screen,
            lambda x: x - 500,
            (0, 1000), (-500, 500),
            (
                asset_loader.pictures["grid"][1][0],
                asset_loader.pictures["grid"][1][1],
                asset_loader.pictures["grid"][0].get_width(),
                asset_loader.pictures["grid"][0].get_height()
            ),
            title="Linear Function"
        ),
        Graph(
            screen,
            lambda x: -0.001 * (x) ** 2 + 500,
            (0, 1000), (-500, 500),
            (
                asset_loader.pictures["grid"][1][0],
                asset_loader.pictures["grid"][1][1],
                asset_loader.pictures["grid"][0].get_width(),
                asset_loader.pictures["grid"][0].get_height()
            ),
            title="Quadratic Function"
        ),
        Graph(
            screen,
            lambda x: - 0.0036 * (x - 500) ** 2 + 400,
            (0, 1000), (-500, 500),
            (
                asset_loader.pictures["grid"][1][0],
                asset_loader.pictures["grid"][1][1],
                asset_loader.pictures["grid"][0].get_width(),
                asset_loader.pictures["grid"][0].get_height()
            ),
            title="Stop and Go"
        ),
        Graph(
            screen,
            lambda x: sinusodial(x),
            (0, 1000), (-500, 500),
            (
                asset_loader.pictures["grid"][1][0],
                asset_loader.pictures["grid"][1][1],
                asset_loader.pictures["grid"][0].get_width(),
                asset_loader.pictures["grid"][0].get_height()
            ),
            title="Sinusoidal Function"
        ),
        Graph(
            screen,
            cool_function,
            (0, 1000), (-500, 500),
            (
                asset_loader.pictures["grid"][1][0],
                asset_loader.pictures["grid"][1][1],
                asset_loader.pictures["grid"][0].get_width(),
                asset_loader.pictures["grid"][0].get_height()
            ),
            title="Complicated Function"
        )]
    graph_index = 0

    # Main loop
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                running = False

            if event.type == KEYDOWN:
                if event.key == K_UP:
                    user.move_y(True)

                elif event.key == K_DOWN:
                    user.move_y(False)

                elif event.key == K_LEFT:
                    graph_index = (graph_index - 1) % len(graphs)
                    user.reset()

                elif event.key == K_RIGHT:
                    graph_index = (graph_index + 1) % len(graphs)
                    user.reset()

            #if event.type == pygame.MOUSEWHEEL:
             #   if event.y > 0:
              #      user.move_y(True)
               # else:
                #    user.move_y(False)

        data_from_arduino = read_line(ser, logger=logger)  # try to read from arduino
        if data_from_arduino == SERIAL_ERROR:  # if arduino WAS connected at start, but now failed to read:
            print("Arduino disconnected! Going to default settings")
            print("Trying to reconnect to Arduino...")
            logger.info("Arduino disconnected... Going to default settings")
            logger.info("Trying to reconnect to Arduino...")

            ser = None
            # if arduino was connecetd at start, but now failed to read, try to reconnect
        if not ser and time.time() - last_time_tried_to_connect > RECONNECT_INTERVAL:
            arduino_port = find_arduino_port(logger=logger)  # find the serial port
            ser = open_serial_connection(arduino_port, logger=logger)  # Open the serial port
            last_time_tried_to_connect = time.time()  # update the last time tried to connect

        if data_from_arduino and data_from_arduino != SERIAL_ERROR:  # if data is vaild
            # print(data_from_arduino)
            distance, error = parse_data(data_from_arduino, logger=logger)
            # print(f"distance: {distance}")
            user.set_y(distance)

        user.add_point()
        has_done_graph = user.move_x()

        if has_done_graph:
            graph_index = (graph_index + 1) % len(graphs)

        user.calc_score(graphs[graph_index])

        screen.fill(BLACK)
        asset_loader.render(screen)
        graphs[graph_index].draw()
        user.render_all()

        pygame.display.flip()
        clock.tick(30)


if __name__ == "__main__":
    main()